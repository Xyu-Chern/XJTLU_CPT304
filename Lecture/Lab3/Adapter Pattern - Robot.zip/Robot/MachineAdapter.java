import code.mac2.*;

class MachineAdapter implements Robot{
    private Machine m;

    public MachineAdapter(Machine m){
        this.m = m;
    }

    @Override
    public void Move(int x, int y, int speed) {
        // TODO Auto-generated method stub
        m.SetSpeed(speed);
        m.Run(x, y);
    }

    @Override
    public void Cook() {
        // TODO Auto-generated method stub
        if(m instanceof ZombieMachine){
            System.out.println("Cooking Zombie food");
        }else if(m instanceof MilitaryMachine){
            System.out.println("Cooking Soldier food");
        }else{
            System.out.println("Cooking cannot be completed");
        }
    }

    
}