package code.mac2;

public abstract class Machine{
    private int speed;

    public void SetSpeed(int speed){
        this.speed = speed;
    }

    public int GetSpeed(){
        return speed;
    }

    public abstract void Kill();

    public abstract void Run(int x, int y);
}