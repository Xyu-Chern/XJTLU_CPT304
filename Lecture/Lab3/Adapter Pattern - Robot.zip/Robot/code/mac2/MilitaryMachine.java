package code.mac2;

public class MilitaryMachine extends Machine{
    @Override
    public void Kill() {
        // TODO Auto-generated method stub
        System.out.println("Aim for the heart");
    }

    @Override
    public void Run(int x, int y) {
        // TODO Auto-generated method stub
        System.out.println("Soldier runs to " + x + "," + y + " at the speed of " + GetSpeed());
    }
}