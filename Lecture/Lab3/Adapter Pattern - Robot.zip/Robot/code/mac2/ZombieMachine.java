package code.mac2;

public class ZombieMachine extends Machine{
    @Override
    public void Kill() {
        // TODO Auto-generated method stub
        System.out.println("Aim for the brain");
    }

    @Override
    public void Run(int x, int y) {
        // TODO Auto-generated method stub
        System.out.println("Zombie runs to " + x + "," + y + " at the speed of " + GetSpeed());
    }
}