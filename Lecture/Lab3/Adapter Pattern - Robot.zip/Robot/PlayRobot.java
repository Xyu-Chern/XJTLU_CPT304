import java.util.ArrayList;
import java.util.List;
import code.mac2.*;

class PlayRobot {
    private List<Robot> robots = new ArrayList<Robot>();

    public void AddRobot(Robot r){
        robots.add(r);
    }

    public void AllRobotsCook(){
        robots.stream().forEach(r -> r.Cook());
    }

    public static void main(String[] args){
        PlayRobot play = new PlayRobot();

        Robot r = new JapaneseRobot();
        play.AddRobot(r);

        r = new ChineseRobot();
        play.AddRobot(r);

        ZombieMachine zm = new ZombieMachine();
        MachineAdapter adapter = new MachineAdapter(zm);
        play.AddRobot(adapter);

        play.AllRobotsCook();
    }
}