// Abstract Document class
abstract class Document {
    abstract void open();
    abstract void save();
    abstract void close();
}

// Concrete Document classes
class WordDocument extends Document {
    void open() { System.out.println("Opening Word Document"); }
    void save() { System.out.println("Saving Word Document"); }
    void close() { System.out.println("Closing Word Document"); }
}

class PDFDocument extends Document {
    void open() { System.out.println("Opening PDF Document"); }
    void save() { System.out.println("Saving PDF Document"); }
    void close() { System.out.println("Closing PDF Document"); }
}

// Abstract Factory
public abstract class DocumentFactory {
    public abstract Document createDocument();

    public Document openDocument(){
        Document doc = createDocument();
        doc.open();
        return doc;
    }
}

// Concrete Factories
class WordDocumentFactory extends DocumentFactory {
    public Document createDocument() { return new WordDocument(); }
}

class PDFDocumentFactory extends DocumentFactory {
    public Document createDocument() { return new PDFDocument(); }
}

// Client code
class DocumentManagementSystem {
    public static void main(String[] args) {
        DocumentFactory wordDocumentFactory = new WordDocumentFactory();
        Document wordDocument = wordDocumentFactory.open();
        wordDocument.save();
        wordDocument.close();
        
        DocumentFactory pdfDocumentFactory = new PDFDocumentFactory();
        Document pdfDocument = pdfDocumentFactory.open();
        pdfDocument.save();
        pdfDocument.close();
    }
}