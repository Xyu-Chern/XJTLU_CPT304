package restaurant;

import burger.BeefBurger;
import burger.Burger;

public class BeefBurgerRestaurant extends Restaurant{

    @Override
    public Burger getBurger() {
        return new BeefBurger();
    }
    
}
