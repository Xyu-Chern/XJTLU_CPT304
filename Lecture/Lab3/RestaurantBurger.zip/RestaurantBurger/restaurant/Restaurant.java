package restaurant;
import burger.Burger;

public abstract class Restaurant {
    public Burger orderBurger(){
        Burger burger = getBurger();
        burger.prepare();
        return burger;
    }

    public abstract Burger getBurger();
}
