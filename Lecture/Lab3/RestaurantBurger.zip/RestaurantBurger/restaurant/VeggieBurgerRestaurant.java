package restaurant;

import burger.Burger;
import burger.VeggieBurger;

public class VeggieBurgerRestaurant extends Restaurant{

    @Override
    public Burger getBurger() {
        return new VeggieBurger();
    }
    
}
