package burger;
public interface Burger {
    public void prepare();
}
