import restaurant.BeefBurgerRestaurant;
import restaurant.Restaurant;

public class Main{
    public static void main(String[] args){
        Restaurant restaurant = new BeefBurgerRestaurant();

        restaurant.orderBurger();
    }
}