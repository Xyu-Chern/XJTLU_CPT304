import java.util.ArrayList;
import java.util.List;

class PlayRobot {
    private List<Robot> robots = new ArrayList<Robot>();

    public void AddRobot(Robot r){
        robots.add(r);
    }

    public void AllRobotsCook(){
        robots.stream().forEach(r -> r.Cook());
    }

    public static void main(String[] args){
        PlayRobot play = new PlayRobot();

        Robot r = new ChineseRobot("Jeremy");
        SmartRobotDecorator sr = new SmartRobotDecorator(r);
        play.AddRobot(sr);

        r = new JapaneseRobot("Sam");
        RationalRobotDecorator rr = new RationalRobotDecorator(r, false);
        play.AddRobot(rr);

        r = new ChineseRobot("Alibaba");
        SmartRobotDecorator sr_1 = new SmartRobotDecorator(r);
        RationalRobotDecorator srr = new RationalRobotDecorator(sr_1, true);

        play.AddRobot(srr);

        play.AllRobotsCook();
    }
}