class JapaneseRobot implements Robot{
    private String name;

    public JapaneseRobot(String name){
        this.name = name;
    }

    @Override
    public void Move(int x, int y, int speed) {
        // TODO Auto-generated method stub
        System.out.println("Japanese Robot moved to " + x + "," + y + " at the speed of " + speed);
    }

    @Override
    public void Cook() {
        // TODO Auto-generated method stub
        System.out.println(name + " is cooking Japanese food");
    }
    
}