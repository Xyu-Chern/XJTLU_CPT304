class ChineseRobot implements Robot{
    private String name;

    public ChineseRobot(String name){
        this.name = name;
    }

    @Override
    public void Move(int x, int y, int speed) {
        // TODO Auto-generated method stub
        System.out.println("Chinese Robot moved to " + x + "," + y + " at the speed of " + speed);
    }

    @Override
    public void Cook() {
        // TODO Auto-generated method stub
        System.out.println(this.name + " is cooking Chinese food");
    }
    
}