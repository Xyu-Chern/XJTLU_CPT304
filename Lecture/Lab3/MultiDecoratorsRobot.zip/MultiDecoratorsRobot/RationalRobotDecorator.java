public class RationalRobotDecorator extends RobotDecorator{
    private boolean gender;

    public RationalRobotDecorator(Robot r, boolean gender) {
        super(r);
        this.gender = gender; // True represent FEMALE
    }

    @Override
    public void Move(int x, int y, int speed) {
        super.Move(x, y, speed);
    }

    @Override
    public void Cook() {
        if(gender){
            System.out.println("I will cook you a small portion");
        } else {
            System.out.println("I will cook you a big portion");
        }
        super.Cook();
    }
}