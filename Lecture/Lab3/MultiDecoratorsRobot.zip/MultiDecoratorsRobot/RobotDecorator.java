public class RobotDecorator implements Robot{
    private Robot r;

    protected RobotDecorator(Robot r){
        this.r = r;
    }

    @Override
    public void Move(int x, int y, int speed) {
        r.Move(x, y, speed);
    }

    @Override
    public void Cook() {
        r.Cook();
    }
}