public class SmartRobotDecorator extends RobotDecorator{

    public SmartRobotDecorator(Robot r) {
        super(r);
    }

    @Override
    public void Move(int x, int y, int speed) {
        super.Move(x, y, speed);
    }

    @Override
    public void Cook() {
        System.out.println("I cook better food");
        super.Cook();
    }
}