public interface Robot{
    public void Move(int x, int y, int speed);

    public void Cook();
}