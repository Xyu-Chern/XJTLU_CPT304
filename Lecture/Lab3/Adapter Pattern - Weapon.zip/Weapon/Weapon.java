public interface Weapon{
    public void fire(int x, int y);

    public void reload(int bulletCount);

    public void upgradeWeapon(int damage);
}