public class Spear extends AncientWeapon{

    public Spear(int damage){
        super(damage);
    }

    @Override
    public void attack() {
        // TODO Auto-generated method stub
        System.out.println("Spear attack location " + getTargetX() + ", " + getTargetY());
    }

}