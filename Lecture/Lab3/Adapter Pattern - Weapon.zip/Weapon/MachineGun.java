public class MachineGun implements Weapon{
    private int bullet;
    private int damage;

    public MachineGun(int bullet){
        this.bullet = bullet;
        this.damage = 5;
    }

    @Override
    public void fire(int x, int y) {
        // TODO Auto-generated method stub
        if(this.bullet >= 5){
            System.out.println("Machine gun firing at " + x + ", " + y);
            this.bullet -= 5;
        }
    }

    @Override
    public void reload(int bulletCount) {
        // TODO Auto-generated method stub
        this.bullet += bulletCount;
    }

    @Override
    public void upgradeWeapon(int damage) {
        // TODO Auto-generated method stub
        this.damage += damage;
    }

}