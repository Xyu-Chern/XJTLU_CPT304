public abstract class AncientWeapon{
    private int targetX;
    private int targetY;
    private int damage;

    public AncientWeapon(int damage){
        this.damage = damage;
    }

    public void setTargetX(int x){    this.targetX = x;    }

    public void setTargetY(int y){    this.targetY = y;    }

    public void setDamage(int damage){    this.damage = damage;    }

    public int getTargetX(){    return this.targetX;    }

    public int getTargetY(){    return this.targetY;    }

    public int getDamage(){    return this.damage;  }

    public void upgrade(int damage){    this.damage += damage;  }

    public abstract void attack();


}