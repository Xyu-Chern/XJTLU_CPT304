import java.util.ArrayList;
import java.util.List;

public class Play {
    public static void main(){
        List<Weapon> weapons = new ArrayList<>();

        weapons.add(new MachineGun(1000));
        weapons.add(new Rifle(50));

        weapons.add(new WeaponAdapter(new Spear(2)));

        for (Weapon weapon : weapons) {
            weapon.fire(20, 135);
        }
    }
}
