public class Rifle implements Weapon{
    private int bullet;
    private int damage;

    public Rifle(int bullet){
        this.bullet = bullet;
        this.damage = 1;
    }

    @Override
    public void fire(int x, int y) {
        // TODO Auto-generated method stub
        if(this.bullet > 0){
            System.out.println("Rifle firing at " + x + ", " + y);
            this.bullet -= 1;
        }
    }

    @Override
    public void reload(int bulletCount) {
        // TODO Auto-generated method stub
        this.bullet += bulletCount;
    }

    @Override
    public void upgradeWeapon(int damage) {
        // TODO Auto-generated method stub
        this.damage += damage;
    }

}