public class WeaponAdapter implements Weapon{
    private AncientWeapon ancientWeapon;

    public WeaponAdapter(AncientWeapon aw){
        this.ancientWeapon = aw;
    }

    @Override
    public void fire(int x, int y) {
        // TODO Auto-generated method stub
        ancientWeapon.setTargetX(x);
        ancientWeapon.setTargetY(y);
        ancientWeapon.attack();
    }

    @Override
    public void reload(int bulletCount) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void upgradeWeapon(int damage) {
        // TODO Auto-generated method stub
        ancientWeapon.upgrade(damage);
    }

}