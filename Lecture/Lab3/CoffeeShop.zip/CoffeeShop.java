// The Coffee interface:
interface Coffee {
    double getCost(); 
    String getDescription();
}

// SimpleCoffee class that implements Coffee interface:
class SimpleCoffee implements Coffee {
    @Override
    public double getCost() {
        return 1.00;
    }

    @Override
    public String getDescription() {
        return "Simple coffee";
    }
}

// Abstract CoffeeDecorator class:
abstract class CoffeeDecorator implements Coffee {
    protected final Coffee decoratedCoffee;

    public CoffeeDecorator(Coffee c) {
        this.decoratedCoffee = c;
    }

    @Override
    public double getCost() {
        return decoratedCoffee.getCost();
    }

    @Override
    public String getDescription() {
        return decoratedCoffee.getDescription();
    }
}

// Milk class that extends CoffeeDecorator:
class Milk extends CoffeeDecorator {
    public Milk(Coffee c) {
        super(c);
    }

    @Override
    public double getCost() {
        return super.getCost() + 0.50;
    }

    @Override
    public String getDescription() {
        return super.getDescription() + ", Milk";
    }
}

// WhippedCream class that extends CoffeeDecorator:
class WhippedCream extends CoffeeDecorator {
    public WhippedCream(Coffee c) {
        super(c);
    }

    @Override
    public double getCost() {
        return super.getCost() + 0.75;
    }

    @Override
    public String getDescription() {
        return super.getDescription() + ", Whipped cream";
    }
}

// Testing our code:
public class CoffeeShop {
    public static void main(String[] args) {
        Coffee myCoffee = new WhippedCream(new Milk(new SimpleCoffee()));
        System.out.println("Cost: " + myCoffee.getCost());
        System.out.println("Description: " + myCoffee.getDescription());
    }
}