// Create the adapter interface
interface PaymentAdapter {
    void makePayment(double amount);
}

// Create the concrete adapter classes
class PayPalPaymentAdapter implements PaymentAdapter {
    PayPalAPI paypalApi = new PayPalAPI();
    
    @Override
    public void makePayment(double amount) {
        paypalApi.processPayment(amount);
    }
}

class CreditCardPaymentAdapter implements PaymentAdapter {
    CreditCardAPI creditCardApi = new CreditCardAPI();
    
    @Override
    public void makePayment(double amount) {
        creditCardApi.charge(amount);
    }
}

class CryptoPaymentAdapter implements PaymentAdapter {
    CryptoAPI cryptoApi = new CryptoAPI();
    
    @Override
    public void makePayment(double amount) {
        cryptoApi.transfer(amount);
    }
}

// The client code in the e-commerce system
class PaymentSystem {
    public void processPayment(String method, double amount) {
        PaymentAdapter paymentAdapter;
        
        switch(method) {
            case "PayPal":
                paymentAdapter = new PayPalPaymentAdapter();
                break;
            case "CreditCard":
                paymentAdapter = new CreditCardPaymentAdapter();
                break;
            case "CryptoCurrency":
                paymentAdapter = new CryptoPaymentAdapter();
                break;
            default:
                throw new IllegalArgumentException("Payment method not supported");
        }
        
        paymentAdapter.makePayment(amount);
    }
}