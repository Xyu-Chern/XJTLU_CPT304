package com.ecommerce.cart;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class testController {
    private test test;

    @Autowired
    public testController(test test) {
        this.test = test;
    }

    @GetMapping("/payment")
    public String testPayment() {
        test.pay(123.42);
        return "Payment processed successfully!";   
    }
}
