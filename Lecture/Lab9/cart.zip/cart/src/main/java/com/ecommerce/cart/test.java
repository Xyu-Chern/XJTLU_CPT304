package com.ecommerce.cart;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.payment.PaymentProcessor;

@Service
public class test {
    private PaymentProcessor paymentProcessor;

    @Autowired
    public test(PaymentProcessor paymentProcessor) {
        this.paymentProcessor = paymentProcessor;
    }

    public void pay(double amount) {
        paymentProcessor.process(amount);
    }
}
