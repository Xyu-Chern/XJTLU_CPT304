package com.paynow.qrpay;

import org.springframework.stereotype.Service;

import com.example.payment.PaymentProcessor;

@Service
public class QrPayment implements PaymentProcessor{

    @Override
    public void process(double arg0) {
        // Implement QR code payment processing logic here
        System.out.println("Processing QR code payment of amount: " + arg0);
    }
    
}
