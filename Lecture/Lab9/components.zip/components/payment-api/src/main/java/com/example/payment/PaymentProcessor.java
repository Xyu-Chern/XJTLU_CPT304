package com.example.payment;

public interface PaymentProcessor {
    void process(double amount);
}