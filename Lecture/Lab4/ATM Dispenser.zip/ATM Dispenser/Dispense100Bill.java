public class Dispense100Bill extends BaseDispenser {
    @Override
    protected int getDenomination() {
        return 100;
    }
}