public class Dollar10Dispenser extends BaseDispenser {
    @Override
    protected int getDenomination() {
        return 10;
    }
}