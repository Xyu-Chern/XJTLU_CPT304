public class Dollar50Dispenser extends BaseDispenser {
    @Override
    protected int getDenomination() {
        return 50;
    }
}