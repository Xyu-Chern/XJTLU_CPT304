public class Dollar20Dispenser extends BaseDispenser {
    @Override
    protected int getDenomination() {
        return 20;
    }
}